import React from 'react';

const LanguageSidebar = () => {
    return (
        <div className="language-sidebar">
            <a href="/" title="LTR Demo">EN</a>
            <a href="/ar" title="RTL Demo">AR</a>
        </div>
    );
}

export default LanguageSidebar;