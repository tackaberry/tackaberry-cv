module.exports = {
  jwtSecret: process.env.JWT_SECRET || '09accf96-f91a-4bcd-95eb-615b3c3a8e5e'
};